let i=0
let aux = i

while(i<100){
    aux += i++
}
console.log(aux)


